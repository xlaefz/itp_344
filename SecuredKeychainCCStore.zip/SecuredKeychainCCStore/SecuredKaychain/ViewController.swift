//
//  ViewController.swift
//  SecuredKaychain
//
//  Created by Demo on 3/1/16.
//  Copyright © 2016 USC. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let itemKey : String = "com.organization.app.ccInfo"
    @IBOutlet weak var mTableView: UITableView!
    
    let keychainItemKey = "com.ITP344.SecuredKeychain.ccInfo"
    public var tableData : Array<Dictionary<String, AnyObject>>?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if(!isLoggedIn){
            return
        }
        
        // loading logic here
        let keychainItem : KeychainItemWrapper = KeychainItemWrapper(identifier:
            itemKey , accessGroup: nil)
        if let keyValue = keychainItem.object(forKey: kSecValueData as String){
            print(keyValue)
            if(tableData == nil){
                tableData = Array<Dictionary<String, AnyObject>>()
                print("made table data")
            }
            let dataString = keychainItem.object(forKey: kSecValueData) as! String
            let data:Data = dataString.data(using: String.Encoding.utf8)!
            do{
                let dictionary: Array<Dictionary<String,AnyObject>> = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! Array<Dictionary<String,AnyObject>>
                tableData = dictionary
//                mTableView.reloadData()
            }catch{
                
            }
            mTableView.reloadData()
        }

        

    }
    
    
    
    //delegate methods
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(tableData?.count)
//        print(tableData!.count)
//        if(tableData == nil){
//            return 0
//        }
//        return tableData!.count
        return 10;
    }
    
    public func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if(editingStyle == UITableViewCellEditingStyle.delete){
            self.tableData?.remove(at: indexPath.row)
            tableView.reloadData()
        }
        
        let datas: Data?;
        
        do{
            datas = try JSONSerialization.data(withJSONObject: tableData!, options: [])
            let dataString = String.init(data:datas!, encoding:String.Encoding.utf8)
            // cardDictionary with cardArray
            
            let keychainItem: KeychainItemWrapper = KeychainItemWrapper (identifier: itemKey, accessGroup:nil)
            
            // this controls when the data is unlocked
            keychainItem.setObject(kSecAttrAccessibleWhenUnlocked, forKey: kSecAttrAccessible)
            keychainItem.setObject(dataString, forKey: kSecValueData as String)
            
        }
        catch{
        }

        
        
        
        
        
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = mTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath as IndexPath)
        
        let row = indexPath.row
        
        if(tableData == nil){
            cell.textLabel?.text = ""
        }else{
            var showText:String = ""
            if(row >= (tableData?.count)!){
                cell.textLabel?.text = ""
                return cell
            }
            for (key,value) in (tableData?[row])!{
                showText += "\(key)->\(value) "
                print("\(key)->\(value)")
            }
            cell.textLabel?.text = showText
        }
        return cell
    }
    
    @IBAction func resetButtonTouched(_ sender: AnyObject) {
		
		let pinKeychainItem : KeychainItemWrapper = KeychainItemWrapper(identifier: pinKey, accessGroup: nil)
		
		pinKeychainItem.resetKeychainItem()
		
		
        let keychainItem : KeychainItemWrapper = KeychainItemWrapper(identifier: keychainItemKey, accessGroup: nil)
        
        keychainItem.resetKeychainItem()
        
    }
}

