//
//  SaveCard.swift
//  SecuredKaychain
//
//  Created by Jason Zheng on 3/22/17.
//  Copyright © 2017 USC. All rights reserved.
//

import UIKit



class SaveCard : UIViewController {
    let itemKey : String = "com.organization.app.ccInfo"
    public var cardArray : Array<Dictionary<String, AnyObject>>?
    
    @IBOutlet weak var CreditCardName: UITextField!
    @IBOutlet weak var CreditCardHolderName: UITextField!
    @IBOutlet weak var CreditCardNumber: UITextField!
    @IBOutlet weak var ExpirationDate: UITextField!
    @IBOutlet weak var SecurityCode: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    
    @IBAction func savePressed(_ sender: Any) {
        if let mCreditCardName = CreditCardName.text{
            if let mCreditCardHolderName = CreditCardHolderName.text{
                if let mCreditCardNumber = CreditCardNumber.text{
                    if let mExpirationDate = ExpirationDate.text{
                        if let mSecurityCode = SecurityCode.text{
                            
                            let keychainItem : KeychainItemWrapper = KeychainItemWrapper(identifier: itemKey, accessGroup: nil)
                            keychainItem.setObject(itemKey, forKey:kSecAttrAccount as String)
                            keychainItem.setObject(kSecAttrAccessibleWhenUnlocked, forKey: kSecAttrAccessible)
                            
                            let dataString = keychainItem.object(forKey: kSecValueData) as! String
                            
                            print ("keychainItem:", keychainItem)
                            
                            let data: Data = dataString.data(using:String.Encoding.utf8)!
                            
                            do {
                                
                                let dictionary: Array< Dictionary <String, AnyObject>> = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as! Array<Dictionary <String, AnyObject>>
                                cardArray = dictionary
                            }
                            catch {
                            }
                            
                            if cardArray == nil {
                                cardArray = Array<Dictionary<String, AnyObject>>();
                            }
                            
                            var cardDictionary : Dictionary <String, AnyObject>? = Dictionary<String, AnyObject>()
                            
                            cardDictionary!["creditcardname"] = mCreditCardName as AnyObject
                            cardDictionary!["creditcardholdername"] = mCreditCardHolderName as AnyObject
                            cardDictionary!["creditcardnumber"] = mCreditCardNumber as AnyObject
                            cardDictionary!["expirationdate"] = mExpirationDate as AnyObject
                            cardDictionary!["securitycode"] = mSecurityCode as AnyObject
                            
                            
                            
                            cardArray?.append(cardDictionary!)
                            
                            let datas: Data?;
                            
                            do{
                                datas = try JSONSerialization.data(withJSONObject: cardArray!, options: [])
                                let dataString = String.init(data:datas!, encoding:String.Encoding.utf8)
                                // cardDictionary with cardArray
                                
                                let keychainItem: KeychainItemWrapper = KeychainItemWrapper (identifier: itemKey, accessGroup:nil)
                                
                                // this controls when the data is unlocked
                                keychainItem.setObject(kSecAttrAccessibleWhenUnlocked, forKey: kSecAttrAccessible)
                                keychainItem.setObject(dataString, forKey: kSecValueData as String)
                                
                            }
                            catch{
                            }
                            
                            print("success")
                            dismiss(animated: true, completion: nil)
                        }
                    }
                }
            }
        }
        return;

    }
}

