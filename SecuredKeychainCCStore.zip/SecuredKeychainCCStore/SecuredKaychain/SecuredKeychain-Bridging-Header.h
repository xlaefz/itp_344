//
//  BridgingHeader.h
//  SecuredKaychain
//
//  Created by Demo on 3/1/16.
//  Copyright © 2016 USC. All rights reserved.
//

#ifndef BridgingHeader_h
#define BridgingHeader_h

#import "KeychainWrapper.h"
#import "KeychainItemWrapper.h"

#endif /* BridgingHeader_h */
